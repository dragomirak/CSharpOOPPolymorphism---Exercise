﻿namespace WildFarm.Models;

public interface ISound
{
    string ProduceSound();
}
